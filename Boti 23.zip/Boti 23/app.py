"""
Chatbot Sewa Jas — Flask + Ollama (LLM lokal)
================================================

Cara pakai (ringkas, detail lengkap ada di README.md):
1. Install Ollama: https://ollama.com/download
2. Tarik model kecil yang ringan di RAM 8GB, mis:
       ollama pull llama3.2:3b
3. Install dependency Python:
       pip install -r requirements.txt
4. Jalankan:
       python app.py
5. Buka browser ke http://localhost:5000
"""

import json
from pathlib import Path

import requests
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

# ============================================================
# 1. KONFIGURASI — sesuaikan di sini kalau perlu
# ============================================================
OLLAMA_URL = "http://localhost:11434/api/chat"

# Model default. qwen2.5:1.5b dipilih karena lebih ringan (~1GB di RAM),
# cocok untuk laptop RAM 8GB. Kalau ingin kualitas jawaban lebih baik dan RAM
# masih longgar, bisa ganti ke "llama3.2:3b" atau "qwen2.5:3b-instruct".
DEFAULT_MODEL = "qwen2.5:1.5b"

# Context window model. Makin besar makin banyak RAM/kv-cache yang dipakai.
# 4096 sudah cukup untuk data toko ini; turunkan ke 2048 kalau laptop berat.
NUM_CTX = 4096
DEFAULT_TEMPERATURE = 0.5

DATA_DIR = Path(__file__).parent
KB_PATH = DATA_DIR / "knowledge_base.json"
INTENTS_PATH = DATA_DIR / "intents.json"


# ============================================================
# 2. LOAD & RINGKAS DATA
#    (bukan RAG vector search — datanya kecil, jadi cukup diringkas
#    lalu ditaruh langsung di system prompt supaya model selalu tahu
#    seluruh info toko di setiap giliran chat)
# ============================================================
def load_data():
    with open(KB_PATH, encoding="utf-8") as f:
        kb = json.load(f)
    with open(INTENTS_PATH, encoding="utf-8") as f:
        intents = json.load(f)["intents"]
    return kb, intents


def rp(n: int) -> str:
    return f"Rp{n:,}".replace(",", ".")


def summarize_kb(kb: dict) -> str:
    info = kb["informasi_toko"]
    produk = kb["produk"]
    paket = kb["paket_sewa"]

    lines = []
    lines.append(f"Nama usaha: {info['nama_usaha']}")
    lines.append(f"Deskripsi: {info['deskripsi']}")
    lines.append(f"Jam operasional: {info['jam_operasional']}")
    lines.append(f"Kontak admin: {info['kontak']}")
    lines.append(f"Alamat: {info['alamat']}")
    lines.append(f"Metode pembayaran: {', '.join(info['metode_pembayaran'])}")
    lines.append(f"Syarat sewa: {'; '.join(info['syarat_sewa'])}")

    denda = info["kebijakan_denda"]
    lines.append(
        f"Denda keterlambatan: {rp(denda['denda_per_hari'])}/hari, toleransi {denda['toleransi_jam']} jam. "
        f"Barang rusak: {denda['denda_barang_rusak']}. Barang hilang: {denda['denda_barang_hilang']}."
    )

    durasi = info["durasi_sewa"]
    lines.append(
        f"Durasi sewa: minimal {durasi['minimal_hari']} hari, maksimal {durasi['maksimal_hari']} hari. "
        f"{durasi['keterangan']}"
    )

    batal = info["kebijakan_pembatalan"]
    lines.append(
        f"Pembatalan/reschedule: DP dikembalikan={'ya' if batal['dp_dikembalikan'] else 'tidak'}, "
        f"boleh reschedule={'ya' if batal['boleh_reschedule'] else 'tidak'}. {batal['keterangan']}"
    )

    antar = info["layanan_antar"]
    lines.append(
        f"Layanan antar: {'tersedia' if antar['tersedia'] else 'tidak tersedia'}, area {antar['area']}, "
        f"biaya {antar['biaya']}. {antar['keterangan']}"
    )

    promo = info["promo"]
    lines.append(f"Promo: {'sedang aktif' if promo['aktif'] else 'belum ada promo aktif'}. {promo['keterangan']}")

    lines.append("\nDaftar produk:")
    for nama, detail in produk.items():
        warna_list = ", ".join(v["warna"] for v in detail["varian_warna"])
        harga = detail["varian_warna"][0]["harga_sewa_per_hari"]
        ukuran = ", ".join(str(u) for u in detail["ukuran_tersedia"])
        lines.append(
            f"- {nama.capitalize()}: {detail['deskripsi']}. Harga {rp(harga)}/hari. "
            f"Ukuran: {ukuran}. Warna: {warna_list}."
        )

    if "size_chart" in produk.get("jas", {}):
        lines.append("\nSize chart jas (ukuran: lingkar dada cm / berat badan kg):")
        for row in produk["jas"]["size_chart"]:
            lines.append(f"- {row['ukuran']}: {row['lingkar_dada_cm']} cm / {row['berat_badan_kg']} kg")

    lines.append("\nPaket sewa:")
    for p in paket:
        catatan = f" ({p['catatan']})" if "catatan" in p else ""
        lines.append(f"- {p['nama_paket']}: {rp(p['harga_sewa_per_hari'])}/hari{catatan}")

    return "\n".join(lines)


def style_examples(intents: list) -> str:
    """Ambil 1 contoh Q&A per intent dari intents.json sebagai referensi gaya bahasa."""
    lines = []
    for intent in intents:
        if intent["intent"] == "tidak_dikenali":
            continue
        contoh = intent["contoh_pertanyaan"][0]
        jawab = intent["jawaban_default"]
        lines.append(f"Q: {contoh}\nA: {jawab}")
    return "\n\n".join(lines)


def build_system_prompt(kb: dict, intents: list) -> str:
    kb_summary = summarize_kb(kb)
    examples = style_examples(intents)
    return f"""Kamu adalah asisten chatbot untuk usaha "{kb['informasi_toko']['nama_usaha']}", jasa sewa jas & formal wear.

ATURAN:
- Jawab HANYA berdasarkan DATA TOKO di bawah ini. Jangan mengarang info yang tidak ada di data.
- Kalau pertanyaan di luar topik toko, atau infonya tidak ada di data, jujur bilang tidak tahu dan arahkan ke kontak admin.
- Gaya bahasa: santai, akrab, ramah seperti admin online shop, boleh pakai emoji secukupnya (jangan berlebihan).
- Jawaban singkat dan jelas, tidak bertele-tele.

=== DATA TOKO ===
{kb_summary}

=== CONTOH GAYA JAWAB (referensi nada bicara, jangan disalin persis) ===
{examples}
"""


KB, INTENTS = load_data()
SYSTEM_PROMPT = build_system_prompt(KB, INTENTS)


# ============================================================
# 3. PEMANGGILAN OLLAMA (streaming)
# ============================================================
def stream_ollama_response(model: str, messages: list, temperature: float):
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {
            "temperature": temperature,
            "num_ctx": NUM_CTX,
        },
    }
    try:
        with requests.post(OLLAMA_URL, json=payload, stream=True, timeout=120) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if not line:
                    continue
                chunk = json.loads(line.decode("utf-8"))
                if chunk.get("done"):
                    break
                content = chunk.get("message", {}).get("content", "")
                if content:
                    yield content
    except requests.exceptions.ConnectionError:
        yield (
            "⚠️ Tidak bisa terhubung ke Ollama. Pastikan Ollama sudah jalan "
            "(buka aplikasi Ollama atau jalankan `ollama serve`), lalu coba lagi."
        )
    except requests.exceptions.HTTPError as e:
        yield f"⚠️ Error dari Ollama: {e}. Pastikan model sudah ditarik, misalnya: `ollama pull {model}`."


# ============================================================
# 4. FLASK APP
# ============================================================
app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", default_model=DEFAULT_MODEL, shop_name=KB["informasi_toko"]["nama_usaha"])


@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json(force=True)
    user_message = (data.get("message") or "").strip()
    history = data.get("history") or []  # [{role, content}, ...] tanpa system prompt
    model = data.get("model") or DEFAULT_MODEL
    temperature = float(data.get("temperature", DEFAULT_TEMPERATURE))

    if not user_message:
        return jsonify({"error": "Pesan kosong."}), 400

    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [
        {"role": "user", "content": user_message}
    ]

    def generate():
        for token in stream_ollama_response(model, messages, temperature):
            yield token

    return Response(stream_with_context(generate()), mimetype="text/plain")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
