(() => {
  const chatLog = document.getElementById("chatLog");
  const chatForm = document.getElementById("chatForm");
  const messageInput = document.getElementById("messageInput");
  const sendBtn = document.getElementById("sendBtn");
  const statusLine = document.getElementById("statusLine");
  const settingsToggle = document.getElementById("settingsToggle");
  const settingsPanel = document.getElementById("settingsPanel");
  const modelInput = document.getElementById("modelInput");
  const tempInput = document.getElementById("tempInput");
  const tempValue = document.getElementById("tempValue");
  const resetBtn = document.getElementById("resetBtn");

  const STORAGE_KEY = "sewa_jas_chat_history";
  let history = loadHistory(); // [{role: 'user'|'assistant', content: '...'}]

  function loadHistory() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch {
      /* localStorage tidak tersedia — percakapan tetap jalan, cuma tidak persist */
    }
  }

  function renderHistory() {
    chatLog.innerHTML = "";
    if (history.length === 0) {
      appendBubble("assistant", "Haiii, selamat datang! 👋 Mau tanya soal ukuran, warna, harga, atau cara sewa? Langsung tulis aja di bawah.", false);
      return;
    }
    for (const m of history) {
      appendBubble(m.role, m.content, false);
    }
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function appendBubble(role, text, animate = true) {
    const wrap = document.createElement("div");
    wrap.className = `msg msg--${role}`;
    const bubble = document.createElement("div");
    bubble.className = "msg__bubble";
    bubble.textContent = text;
    wrap.appendChild(bubble);
    chatLog.appendChild(wrap);
    if (animate) chatLog.scrollTop = chatLog.scrollHeight;
    return bubble;
  }

  function autoResize() {
    messageInput.style.height = "auto";
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + "px";
  }
  messageInput.addEventListener("input", autoResize);

  settingsToggle.addEventListener("click", () => {
    settingsPanel.classList.toggle("hidden");
  });

  tempInput.addEventListener("input", () => {
    tempValue.textContent = tempInput.value;
  });

  resetBtn.addEventListener("click", () => {
    history = [];
    saveHistory();
    renderHistory();
    statusLine.textContent = "";
  });

  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = messageInput.value.trim();
    if (!text) return;

    messageInput.value = "";
    autoResize();
    sendBtn.disabled = true;

    appendBubble("user", text);
    history.push({ role: "user", content: text });
    saveHistory();

    const assistantBubble = appendBubble("assistant", "", true);
    assistantBubble.classList.add("typing");
    statusLine.textContent = `Menghubungi model ${modelInput.value}...`;

    try {
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: history.slice(0, -1), // riwayat sebelum pesan ini (server akan tambahkan pesan user)
          model: modelInput.value.trim() || undefined,
          temperature: parseFloat(tempInput.value),
        }),
      });

      if (!resp.ok || !resp.body) {
        throw new Error(`HTTP ${resp.status}`);
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let fullText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunkText = decoder.decode(value, { stream: true });
        fullText += chunkText;
        assistantBubble.textContent = fullText;
        chatLog.scrollTop = chatLog.scrollHeight;
      }

      assistantBubble.classList.remove("typing");
      history.push({ role: "assistant", content: fullText });
      saveHistory();
      statusLine.textContent = "";
    } catch (err) {
      assistantBubble.classList.remove("typing");
      assistantBubble.textContent =
        "⚠️ Gagal terhubung ke server. Pastikan aplikasi Flask (python app.py) dan Ollama sama-sama sedang berjalan.";
      statusLine.textContent = "Terjadi kesalahan koneksi.";
    } finally {
      sendBtn.disabled = false;
      messageInput.focus();
    }
  });

  // Kirim dengan Enter, baris baru dengan Shift+Enter
  messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      chatForm.requestSubmit();
    }
  });

  renderHistory();
})();
